import React, { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { FaCheck, FaTimes, FaSearch, FaFilter, FaSync } from 'react-icons/fa';

export default function AdminDashboard() {
  const { theme } = useTheme();
  const [requests, setRequests] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('hostelRequests')) || [];
    } catch (error) {
      console.error("Error parsing requests:", error);
      return [];
    }
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const handleStatusChange = (id, newStatus) => {
    const updatedRequests = requests.map(request => 
      request.id === id ? { ...request, status: newStatus } : request
    );
    setRequests(updatedRequests);
    localStorage.setItem('hostelRequests', JSON.stringify(updatedRequests));
  };

  const filteredRequests = requests.filter(request => {
    const matchesSearch = request.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         request.room.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || request.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const refreshRequests = () => {
    try {
      const updatedRequests = JSON.parse(localStorage.getItem('hostelRequests')) || [];
      setRequests(updatedRequests);
    } catch (error) {
      console.error("Error refreshing requests:", error);
    }
  };

  return (
    <div className={`min-h-screen p-6 ${theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-100'}`}>
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Request Management</h1>
          <button 
            onClick={refreshRequests}
            className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-white hover:bg-gray-200'} shadow`}
          >
            <FaSync className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'} />
          </button>
        </div>
        
        <div className="mb-6 flex flex-col md:flex-row gap-4">
          <div className={`relative flex-grow ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow`}>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaSearch className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'} />
            </div>
            <input
              type="text"
              placeholder="Search requests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full pl-10 pr-4 py-2 rounded-lg ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white'} focus:outline-none focus:ring-2 focus:ring-indigo-500`}
            />
          </div>
          
          <div className={`flex items-center ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow px-4`}>
            <FaFilter className={`mr-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`} />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className={`py-2 pl-2 pr-8 rounded-lg ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white'} focus:outline-none focus:ring-2 focus:ring-indigo-500`}
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
        
        <div className={`rounded-lg shadow-md overflow-hidden ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
          <div className={`grid grid-cols-12 p-4 font-semibold ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <div className="col-span-2 md:col-span-1">ID</div>
            <div className="col-span-3 md:col-span-2">Name</div>
            <div className="col-span-2 md:col-span-1">Room</div>
            <div className="col-span-2 hidden md:block">Type</div>
            <div className="col-span-2">Status</div>
            <div className="col-span-3 md:col-span-2">Actions</div>
          </div>
          
          {filteredRequests.length === 0 ? (
            <div className="p-6 text-center">No requests found</div>
          ) : (
            filteredRequests.map(request => (
              <div key={request.id} className={`grid grid-cols-12 p-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
                <div className="col-span-2 md:col-span-1">#{request.id.toString().slice(-4)}</div>
                <div className="col-span-3 md:col-span-2 truncate">{request.name}</div>
                <div className="col-span-2 md:col-span-1">{request.room}</div>
                <div className="col-span-2 hidden md:block">{request.requestType}</div>
                <div className="col-span-2">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    request.status === 'approved' ? 
                      (theme === 'dark' ? 'bg-green-900 text-green-200' : 'bg-green-100 text-green-800') :
                    request.status === 'rejected' ? 
                      (theme === 'dark' ? 'bg-red-900 text-red-200' : 'bg-red-100 text-red-800') :
                      (theme === 'dark' ? 'bg-yellow-900 text-yellow-200' : 'bg-yellow-100 text-yellow-800')
                  }`}>
                    {request.status}
                  </span>
                </div>
                <div className="col-span-3 md:col-span-2 flex space-x-2">
                  {request.status === 'pending' && (
                    <>
                      <button 
                        onClick={() => handleStatusChange(request.id, 'approved')}
                        className={`px-2 py-1 rounded text-xs flex items-center ${
                          theme === 'dark' ? 'bg-green-600 hover:bg-green-700' : 'bg-green-500 hover:bg-green-600'
                        } text-white`}
                      >
                        <FaCheck className="mr-1" /> Approve
                      </button>
                      <button 
                        onClick={() => handleStatusChange(request.id, 'rejected')}
                        className={`px-2 py-1 rounded text-xs flex items-center ${
                          theme === 'dark' ? 'bg-red-600 hover:bg-red-700' : 'bg-red-500 hover:bg-red-600'
                        } text-white`}
                      >
                        <FaTimes className="mr-1" /> Reject
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}